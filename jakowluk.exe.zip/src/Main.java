import java.awt.Graphics2D;
import javax.swing.JPanel;

public class Main {
    public static void main(String[] args) {
        new MyFrame();
    }
}